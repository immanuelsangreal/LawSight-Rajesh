<?php
/* Add extra type on visual composer */
require_once CMS_INCLUDES.'types/cms_template.php';
require_once CMS_INCLUDES.'types/cms_template_img.php';
require_once CMS_INCLUDES.'types/cms_select_file.php';
require_once CMS_INCLUDES.'types/img.php';
/* Get List Shortcodes From Folder*/
require_once CMS_DIR . '/shortcodes/cms_base.php';