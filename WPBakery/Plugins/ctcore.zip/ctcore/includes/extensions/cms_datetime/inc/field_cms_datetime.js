jQuery(function ($) {
    $('.cms-datetime').datetimepicker({
        timeFormat: "HH:mm",
        dateFormat : 'yy-mm-dd'
    });
});