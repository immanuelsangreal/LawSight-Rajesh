/**
 * @team: FsFlex Team
 * @since: 1.0.0
 * @author: CaseThemes
 */
(function ($) {
    console.log($('.cms-icon-picker'));
})(jQuery);
